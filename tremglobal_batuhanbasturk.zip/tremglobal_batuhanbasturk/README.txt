Merhaba,

Elimden gelenin en iyisi bu değil Vue JS öğrenmeye yeni başladım dolu dolu bir hafta bile geçirmedim, öğrenilecek çok şey olduğunu düşünüyorum. Mail deki son soruyu pek anlayamadım. Bu sebepten dönen değeri olduğu gibi jsona çevirerek bastım. (Functions.php dosyası içerisinde). Bir sonraki projeyi takımınızla beraber yazma dileklerimle.

Not: Şehven bazı kısımlarda firma adını yanlış yazdım. Önemsenmemesini arz ederim.



Saygılarımla
Batuhan Baştürk