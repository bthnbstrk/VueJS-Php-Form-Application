<template>
<div>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <img src="https://www.tremglobal.com/assets/images/tremglobal-logo.svg" alt="" width="100" height="50">
  <span>APPLICATION FORM</span>
  </nav>

</div>
</template>

<script>
export default {
  name: 'Banner',
  props: {
    msg: String
  }
}
</script>
<style scoped>
span{
  margin-left: 30%;
  font-size: 20px;
  color:#EF6624;
}
</style>
