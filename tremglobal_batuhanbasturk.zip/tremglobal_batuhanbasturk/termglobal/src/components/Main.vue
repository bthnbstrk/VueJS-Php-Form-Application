<template>
  <div class="top">
    <form @submit.prevent="onSubmit">
      <!--
      Error Handlig
      <p v-if="errors.length">
        <b>Please correct the following error(s):</b>
      <ul>
        <li v-for="error in errors">{{ error }}</li>
      </ul>
      </p>
      -->
      <div class="form-group">
        <label>Firstname</label>
        <input required type="text" v-model="post.firstname" class="form-control"
               placeholder="Please write your firstname...">
      </div>
      <div class="form-group">
        <label>Lastname</label>
        <input required type="text" v-model="post.lastname" class="form-control"
               placeholder="Please write your lastname...">
      </div>
      <div class="form-group">
        <MazPhoneNumberInput
            v-model="post.phoneNumber"
            @update="results = $event"
        />
      </div>

      <div class="form-group">
        <label>Email</label>
        <input required type="email" v-model="post.email" class="form-control"
               placeholder="Please write your email address...">
      </div>
      <div class="form-group">
        <label>Message</label>
        <textarea class="form-control" v-model="post.message" rows="4"
                  required placeholder="Please write your messages..."></textarea>
      </div>
      <div class="form-group">
        <label>Reference Full Name</label>
        <input type="text" class="form-control" v-model="post.fullnameReference"
               required placeholder="Please write your reference person firstname...">
      </div>
      <div class="form-group">
        <MazPhoneNumberInput
            v-model="post.phoneNumberReference"
            @update="results = $event"
        />
      </div>

      <button class="btn btn-success col-lg-12" type="submit">SEND</button>
    </form>
  </div>
</template>
<style scoped>
.top {
  margin: 4%
}
</style>

<script>
import {MazPhoneNumberInput} from 'maz-ui';
import axios from 'axios';

export default {
  name: 'Main',
  components: {MazPhoneNumberInput},
  data() {
    return {
      post: {
        firstname: "",
        lastname: "",
        email: "",
        message: "",
        fullnameReference: "",
        phoneNumber: null,
        phoneNumberReference: null,
        results: null
      }
    }
  },
  methods: {
    onSubmit() {
      if (this.results.isValid === true) {
        axios.post("http://localhost/tremglobalphp/", {...this.post, userLanguage: window.navigator.language})
            .then(response => {
              console.log(response);
            }).catch(e => console.log(e));
      }
    },
  }
}
</script>



