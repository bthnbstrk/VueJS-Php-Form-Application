import Vue from 'vue'
import App from './App.vue'
import {  MazPhoneNumberInput } from 'maz-ui'
import "maz-ui/lib/css/index.css";
import MazUi from "maz-ui";



Vue.use(MazUi,MazPhoneNumberInput);
Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
