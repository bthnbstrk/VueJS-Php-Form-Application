-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 16 Eyl 2021, 00:31:57
-- Sunucu sürümü: 10.4.20-MariaDB
-- PHP Sürümü: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `term_global`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `applications`
--

CREATE TABLE `applications` (
  `id` int(11) NOT NULL,
  `first_name` varchar(70) NOT NULL,
  `last_name` varchar(70) NOT NULL,
  `telephone_number` varchar(40) NOT NULL,
  `email` varchar(60) NOT NULL,
  `message` text NOT NULL,
  `created_date` datetime NOT NULL,
  `user_language` varchar(20) NOT NULL,
  `reference_phone` varchar(40) NOT NULL,
  `reference_full_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `applications`
--

INSERT INTO `applications` (`id`, `first_name`, `last_name`, `telephone_number`, `email`, `message`, `created_date`, `user_language`, `reference_phone`, `reference_full_name`) VALUES
(2, 'Qui placeat dolor d', 'Dolor reprehenderit', '+1 1 425 962 116', 'qumuvatog@mailinator.com', 'Doloremque similique', '2021-09-09 23:32:50', 'tr-TR', '+13256169386', 'Fugiat ut in minima'),
(3, 'Reprehenderit volupt', 'Voluptatibus accusam', '+905019021211', 'saqovyvop@mailinator.com', 'Voluptatibus perfere', '2021-09-15 23:48:42', 'tr-TR', '+16725615415', 'Saepe magni nobis au'),
(4, 'Aliquid veritatis ut', 'Atque eaque odio in ', '+13644241538', 'lybeg@mailinator.com', 'Impedit reprehender', '2021-09-15 23:49:33', 'tr-TR', '+16622828714', 'Voluptatem Quia ani'),
(5, 'Aliquid veritatis ut', 'Atque eaque odio in ', '+13644241538', 'lybeg@mailinator.com', 'Impedit reprehender', '2021-09-15 23:49:40', 'tr-TR', '+16622828714', 'Voluptatem Quia ani'),
(6, 'Aliquid veritatis ut', 'Atque eaque odio in ', '+13644241538', 'lybeg@mailinator.com', 'Impedit reprehender', '2021-09-15 23:49:42', 'en-EN', '+16622828714', 'Voluptatem Quia ani'),
(7, 'Aliquid veritatis ut', 'Atque eaque odio in ', '+13644241538', 'lybeg@mailinator.com', 'Impedit reprehender', '2021-09-13 23:49:44', 'en-EN', '+16622828714', 'Voluptatem Quia ani'),
(8, 'Aliquid veritatis ut', 'Atque eaque odio in ', '+13644241538', 'lybeg@mailinator.com', 'Impedit reprehender', '2021-09-15 23:49:45', 'en-EN', '+16622828714', 'Voluptatem Quia ani'),
(9, 'Aliquid veritatis ut', 'Atque eaque odio in ', '+13644241538', 'lybeg@mailinator.com', 'Impedit reprehender', '2021-09-01 23:49:45', 'en-EN', '+16622828714', 'Voluptatem Quia ani'),
(10, 'Aliquid veritatis ut', 'Atque eaque odio in ', '+13644241538', 'lybeg@mailinator.com', 'Impedit reprehender', '2021-09-15 23:49:45', 'en-EN', '+16622828714', 'Voluptatem Quia ani'),
(11, 'Aliquid veritatis ut', 'Atque eaque odio in ', '+13644241538', 'lybeg@mailinator.com', 'Impedit reprehender', '2021-09-15 23:49:45', 'tr-TR', '+16622828714', 'Voluptatem Quia ani'),
(16, 'Aliquid veritatis ut', 'Atque eaque odio in ', '+13644241538', 'lybeg@mailinator.com', 'Impedit reprehender', '2021-09-15 23:51:34', 'tr-TR', '+16622828714', 'Voluptatem Quia ani'),
(17, 'Ullam at adipisicing', 'Dolorem ab qui tempo', '+18122349614', 'jebac@mailinator.com', 'Et tempore est est', '2021-09-15 23:53:26', 'tr-TR', '+19514977274', 'Aute excepturi magni');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `applications`
--
ALTER TABLE `applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
