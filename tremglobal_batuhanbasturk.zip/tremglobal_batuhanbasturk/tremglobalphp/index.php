<?php
  require_once 'connection.php';
  if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');
  }

  if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
      header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
      header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
  }


  $acceptable_languages = ['tr-TR'];


  if (isset($_POST)) {

    $data = json_decode(file_get_contents('php://input'), true);
    if (in_array($data['userLanguage'], $acceptable_languages)) {

        $firstname=$data['firstname'];
        $lastname=$data['lastname'];
        $email=$data['email'];
        $telephone_number=$data['phoneNumber'];
        $message=$data['message'];
        $created_date=date('Y-m-d H:i:s');
        $user_language=$data['userLanguage'];
        $reference_phone=$data['phoneNumberReference'];
        $reference_full_name=$data['fullnameReference'];

      $sql = "INSERT INTO applications (first_name, last_name, telephone_number,email,message,created_date,user_language,reference_phone,reference_full_name) VALUES ('$firstname', '$lastname', '$telephone_number','$email','$message','$created_date','$user_language','$reference_phone','$reference_full_name')";
      if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        die;
      }
    } else {
      echo "Your language is unacceptable";
    }

  }


?>

