<?php



  function get_report(){

    include_once 'connection.php';
    $sql = "SELECT *  FROM applications where WEEKOFYEAR(created_date)=WEEKOFYEAR(NOW())";
    $result = $conn->query($sql);
    $data=array();
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        $object=array(
          "firstname"=>$row["first_name"],
          "lastname"=>$row["last_name"],
          "email"=>$row["email"],
          "phone"=>$row["telephone_number"],
          "message"=>$row["message"],
          "date"=>$row["created_date"],
          "userlanguage"=>$row["user_language"],
          "reference_fullname"=>$row["reference_full_name"],
          "reference_phone"=>$row["reference_phone"],
        );
        array_push($data,$object);
      }
      return $data;
    } else {
     return $data;
    }
  }

$last_array = get_report();
$json=json_encode($last_array);
die(($json));